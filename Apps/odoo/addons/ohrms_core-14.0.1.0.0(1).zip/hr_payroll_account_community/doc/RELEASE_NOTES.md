## Module <hr_payroll_account_community>

#### 03.10.2020
#### Version 14.0.1.0.0
#### ADD
- Initial commit

