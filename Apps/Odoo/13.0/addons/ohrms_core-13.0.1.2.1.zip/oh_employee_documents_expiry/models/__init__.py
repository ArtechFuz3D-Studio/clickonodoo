# -*- coding: utf-8 -*-

from . import employee_documents
from . import document_type
from . import hr_documents

