## Module <hr_employee_updation>

#### 19.05.2018
#### Version 13.0.2.0.0
##### FIX
- Bug fixed (key error: employee_ref)

#### 10.04.2018
#### Version 13.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
