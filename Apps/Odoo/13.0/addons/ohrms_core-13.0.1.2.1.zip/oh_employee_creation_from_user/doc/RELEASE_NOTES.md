## Module <hr_employee_creation_from_user>

#### 22.05.2019
#### Version 13.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
