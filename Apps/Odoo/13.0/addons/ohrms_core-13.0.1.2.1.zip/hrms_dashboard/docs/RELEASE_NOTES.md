## Module <hrms_dashboard>

#### 13.03.2019
#### Version 13.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project


#### 25.11.2020
#### Version 13.0.1.0.1
##### FIX
- Bu Fixed
